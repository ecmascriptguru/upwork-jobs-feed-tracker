const styles = {
  main: {
    padding: "20px 0"
  },
  logoImage: {
    height: "48px"
  },
  authSection: {
    textAlign: "right"
  }
};

export default styles;
