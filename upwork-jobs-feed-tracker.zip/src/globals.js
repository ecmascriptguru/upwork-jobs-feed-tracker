export const badgeColor = '#f44e42';

export const jobsAlarmKey = 'JOBS_ALARM_KEY';

export const globalStateKey = 'STATE';
