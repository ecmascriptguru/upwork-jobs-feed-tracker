const styles = {
  rootContainer: {
    minWidth: '640px',
    textAlgin: 'center',
    position: 'relative'
  },
};
  
export default styles;
  