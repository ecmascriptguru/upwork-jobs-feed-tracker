const styles = {
  rootContainer: {
    minWidth: '960px',
    padding: '50px 0 300px',
    position: 'relative'
  },
  jobsContainer: {
    padding: '0 30px'
  }
};

export default styles;
