import { openUrl } from './chrome';

export const openOptionsPage = () => openUrl('index.html#options');
export const openFindPage = () => {}
