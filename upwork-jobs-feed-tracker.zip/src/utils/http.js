export const isUnauthenticatedError = response =>
  response.status === 401;
